import java.util.Currency;

/**
 * A set of rational numbers implemented as a binary search tree. There are no
 * duplicate entries in this set (no two elements e1 and e2 for which e1.compareTo(e2) == 0). The
 * elements are sorted according to their value (the ordering is given by the method 'compareTo'
 * of class 'Rational').
 */
//
// TODO: define further classes and methods for the implementation of the binary search tree,
//   if needed. Do NOT use the Java-Collection framework in your implementation.
//
public class TreeSetRational {

    // TODO: define missing parts of the class.
    RNode root;
    int count = 0;

    /**
     * Initialises 'this' as an empty set.
     */
    public TreeSetRational() {
        // TODO: implement constructor.
    }

    /**
     * Adds the specified rational number to the set.
     * Returns 'true' if the set did not already contain the specified element
     * and 'false' otherwise.
     * @param r the rational number to add to this set, r != null.
     *          -1 -> left
     *          0 -> equal
     *          1 -> right
     */
    public boolean add(Rational r) {
        if(root == null){
            root = new RNode(r);
            count++;
            System.out.println("| TreeSetRational | add | INFO | Adding " + r.toString() + " and making it " + count + " Elements in the tree");
            return true;
        }

        if (r != null){
            RNode NewNode = new RNode(r);
            RNode CurrentNode = root;


            while(true){
                if (CurrentNode.getVRational().compareTo(r)==0){
                    System.out.println("| TreeSetRational | add | ERROR | Number already in the tree (" + r.toString() + ")");
                    return false;
                } else if (CurrentNode.getVRational().compareTo(r)==1) {
                    if(CurrentNode.getLeft() != null){
                        CurrentNode = CurrentNode.getLeft();
                    }else{
                        CurrentNode.setLeft(NewNode);
                        count++;
                        System.out.println("| TreeSetRational | add | INFO | Adding " + r.toString() + " and making it " + count + " Elements in the tree");
                        return true;
                    }
                } else {
                    if(CurrentNode.getRight() != null){
                        CurrentNode = CurrentNode.getRight();
                    }else{
                        CurrentNode.setRight(NewNode);
                        count++;
                        System.out.println("| TreeSetRational | add | INFO | Adding " + r.toString() + " and making it " + count + " Elements in the tree");
                        return true;
                    }
                }
            }
        }
        System.out.println("| TreeSetRational | add | ERROR | Number is null");
        return false;
    }

    /**
     * Returns a new 'TreeSetRational' object that is the union of this set and the 'other' set.
     * 'this' and 'other' are not changed by this method.
     * @param other the second operand != null.
     */
    public TreeSetRational union(TreeSetRational other) {

        Rational[] thisNumArray = treeCheck(this.count, root);
        Rational[] otherNumArray = treeCheck(other.count, other.root);

        TreeSetRational retTree = new TreeSetRational();

        for ( Rational r : thisNumArray) {
            retTree.add(r);
        }

        for ( Rational r : otherNumArray) {
            retTree.add(r);
        }
        System.out.println("| TreeSetRational | union | INFO | Merging/unionising 2 Trees");
        System.out.println("| TreeSetRational | union | INFO | This:   " + this.toString() + " and other: " + other.toString());
        System.out.println("| TreeSetRational | union | INFO | Result: " + retTree.toString());
        return retTree;
    }

    /**
     * Returns the number of rational numbers in the set that are within the range defined by
     * the lowest and highest rational number (inclusive). The method exploits the structure of
     * the binary search tree and traverses only relevant parts of the tree.
     * @param highest the upper bound of the range.
     * @param lowest the lower bound of the range.
     * The following preconditions hold for 'highest' and 'lowest':
     *        lowest != null && highest != null && lowest.compareTo(highest) <= 0.
     * @return number of rational numbers in the set that are within the specified range.
     */
    public int countWithinRange(Rational lowest, Rational highest) {

        if(root == null) return 0;
        int count = 0;

        Rational[] numArray = treeCheck(this.count, root);
        for (int i = 0; i < this.count; i++) {
            if(numArray[i].compareTo(lowest) != -1 && numArray[i].compareTo(highest) != 1){
                count++;
            }
        }
        System.out.println(toString());
        System.out.println("| TreeSetRational | countWithinRange | INFO | Es wurden " + count + " Elemente zwischen " + lowest + " und " + highest + " gefunden");
        return count;
    }

    /**
     * Removes the lowest rational number from this set. Returns the rational number that was
     * removed from this set or 'null' if this set is empty.
     * (The corresponding node is removed by replacing it with the subtree of the node that
     * contains entries greater than the minimum.)
     * @return the lowest rational number from this set or 'null' if this set is empty.
     */
    public Rational removeMinimum() {

        Rational[] numArray = treeCheck(this.count, root);
        if(root == null) return null; // falls kein baum
        else if (root.getVRational() == numArray[0]) {
            if(root.getRight() != null){  // falls root das kleinste ist und es rechts weiter geht
                root = root.getRight();
                this.count--;
                return numArray[0];
            }else{  // falls root das kleinste ist und auch das einzige element
                root = null;
                this.count--;
                return numArray[0];
            }
        }

        RNode currentNode = root;

        for (int i = 0; i < count; i++) {
            if(currentNode.getLeft().getVRational().compareTo(numArray[0]) == 0){ // schaut ob links gleich ist wie das kleinste element

                if(currentNode.getLeft().getRight() != null){ // wenn es nen rechts weg vom kleinsten gibt rückt der nach
                    currentNode.setLeft(currentNode.getLeft().getRight());
                }else{
                    currentNode.setLeft(null); // wenn ned, ist das derzeitige element das neue kleinste
                }
                this.count--;
                return numArray[0];
            }
            currentNode = currentNode.getLeft();
        }

        return null;
    }

    /**
     * Returns a string representation of 'this' with all rational objects
     * ordered ascending. The format of the string uses
     * brackets and is as in the following example with a set of four elements:
     * "[-3/4, -2/3, -1/3, 1/2]"
     * Returns "[]" if this set is empty.
     * @return the string representation of 'this'.
     */
    public String toString() {

        Rational[] numArray = treeCheck(count,root);
        String ret = "[";
        if(numArray.length > 0) {
            for (int i = 0; i < numArray.length - 1; i++) {
                if (numArray[i] == null) break;
                ret += numArray[i] + ", ";
            }
            ret += numArray[numArray.length - 1];
        }
        return ret + "]";
    }

    /**
    * goes through the tree and returns an array with all the values
    * */
    public Rational[] treeCheck(int size, RNode currNode){
        Rational[] numArray = new Rational[size];
        if(currNode == null) return numArray;
        int mid = 0;
        if(currNode.getLeft() != null){// falls es links weiter geht gema weiter und fügen was kommt zum array dazu
            Rational[] temp = treeCheck(size - 1, currNode.getLeft());
            for( int i = 0; i < size-1; i++){
                if(temp[i]==null) break;
                numArray[i] =  temp[i];
                mid++;
            }
        }

        numArray[mid] = currNode.getVRational();
        mid++;

        if (currNode.getRight() != null) {// falls es rechts weiter geht gema rechts alles durch und fügen
            Rational[] temp = treeCheck(size - 1, currNode.getRight());
            for( int i = 0; i < size-1; i++){
                if(temp[i] == null){
                    break;
                }
                numArray[mid+i] =  temp[i];
            }
        }

        return numArray;
    }

    /**
    * goes through the array and checks the number of elements
    * */


}

// TODO: define further classes, if needed (either here or in a separate file).

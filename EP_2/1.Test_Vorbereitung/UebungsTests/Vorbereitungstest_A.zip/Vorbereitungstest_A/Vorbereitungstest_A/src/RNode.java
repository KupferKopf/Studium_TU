public class RNode {

    Rational VRational;
    RNode left; // smaller than current rational
    RNode right; // lager then current rational

    public RNode(Rational rational){
        if(rational != null){
            VRational = rational;
        }else{
            VRational = new Rational(1,1);
        }
    }

    public Rational getVRational(){
        return VRational;
    }

    public RNode getLeft(){
        if(left == null) return null;
        return left;
    }

    public RNode getRight(){
        if(right == null) return null;
        return right;
    }

    public void setLeft(RNode node){
        if(node != null){
            left = node;
        }else{
            left = null;
            System.out.println("| RNode | setLeft | MINOR-ERROR | node was set as null ");
        }
    }

    public void setRight(RNode node){
        if(node != null){
            right = node;
        }else{
            left = null;
            System.out.println("| RNode | setRight | MINOR-ERROR | node was set as null ");
        }
    }

}

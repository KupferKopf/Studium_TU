public class MonoNode {

    private IntConst keyConst; //key Constante
    private IntConst valConst; //value Constante

    private MonoNode left;
    private MonoNode right;


    public MonoNode(IntConst keyConst, IntConst valConst){
        if(keyConst != null && valConst != null){
            this.keyConst = keyConst;
            this.valConst = valConst;
        }else{
            System.out.println("| MonoNode | Constructor | ERROR | Einer der 2 values ist null");
        }
    }

    public IntConst getKeyConst() {
        return keyConst;
    }

    public void setKeyConst(IntConst keyConst) {
        if(keyConst != null) this.keyConst = keyConst;
        else{
            System.out.println("| MonoNode | setKeyConst | ERROR | val ist null");
        }
    }

    public IntConst getValConst() {
        return valConst;
    }

    public void setValConst(IntConst valConst) {
       if(valConst != null) this.valConst = valConst;
       else{
           System.out.println("| MonoNode | setValConst | ERROR | val ist null");
       }
    }

    public MonoNode getLeft() {
        return left;
    }

    public void setLeft(MonoNode left) {
        if(left != null)this.left = left;
        else{
            System.out.println("| MonoNode | setLeft | ERROR | val ist null");
        }
    }

    public MonoNode getRight() {
        return right;
    }

    public void setRight(MonoNode right) {
        if(right != null)this.right = right;
        else{
            System.out.println("| MonoNode | setRight | ERROR | val ist null");
        }
    }
}

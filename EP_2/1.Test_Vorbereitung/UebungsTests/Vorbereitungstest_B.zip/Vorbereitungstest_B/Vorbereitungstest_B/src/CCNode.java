public class CCNode { // Caravan Camel Node

    CCNode nextCamel;
    Camel camelStats;

    public CCNode(Camel camel){
        camelStats = camel;
    }

    public void setNextCamel(CCNode node){
        if(node != null){
            nextCamel = node;
        }else{
            System.out.println("| CCNode | setNextCamel | MINOR-ERROR | node was null but still set");
            nextCamel = null;
        }
    }

    public void setCamelStats(Camel camel){
        if(camel != null){
            camelStats = camel;
        }else{
            System.out.println("| CCNode | setCamelStats | MINOR-ERROR | camel was null but still set");
            camelStats = null;
        }
    }

    public CCNode getNextCamel(){
        return nextCamel;
    }

    public Camel getCamelStats(){
        return camelStats;
    }

    @Override
    public String toString() {
        return "Camelstats: " + camelStats.toString() + " |  NextCamel: " + nextCamel;
    }
}
